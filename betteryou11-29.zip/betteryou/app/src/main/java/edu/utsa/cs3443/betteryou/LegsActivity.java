package edu.utsa.cs3443.betteryou;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class LegsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_legs);
    }
    //TODO Info for legs

}
